export const COMMON_DI_CONSTANTS = {
  IConfigService: Symbol.for('IConfigService'),
  IConfig: Symbol.for('IConfig'),
};
