export const DI_CONSTANTS = {
  common: Symbol.for('common'),
};
