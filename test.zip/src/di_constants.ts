export const DI_CONSTANTS = {
  IAppService: Symbol.for('IAppService'),
  IRedisService: Symbol.for('IAppService'),
};
