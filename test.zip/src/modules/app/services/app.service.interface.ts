export interface IAppService {
  init(): Promise<void>;
}
